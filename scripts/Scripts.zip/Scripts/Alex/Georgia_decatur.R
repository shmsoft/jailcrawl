source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_decatur_", "http://decaturcoga.offenderindex.com")