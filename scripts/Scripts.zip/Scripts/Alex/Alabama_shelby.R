source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_shelby_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://inmatelisting.shelbyal.com/" %>%
  rvestGetHTML(fileName, FALSE)

endCrawl()