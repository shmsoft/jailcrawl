source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Florida_osceola_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://apps.osceola.org/Apps/CorrectionsReports/Report/Search/" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("#content > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[c(TRUE, FALSE, FALSE, FALSE, FALSE)]

linkz <- paste("http://apps.osceola.org", linkz, sep = "")
idz <- substr(linkz, regexpr("Details", linkz) + 8, nchar(linkz))
for(j in 1:length(linkz)){
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "Florida_osceola_", Sys.Date(),"_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()