source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arizona_cochise_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.cochise.az.gov/sites/default/files/sheriff/public_info/mug_shots.pdf", fileName, mode = "wb")

endCrawl()