source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_napa_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rvestGetHTML(link = "https://services.countyofnapa.org/CJNetWeb/Public/InCustodyReport", fileName, FALSE)

endCrawl()