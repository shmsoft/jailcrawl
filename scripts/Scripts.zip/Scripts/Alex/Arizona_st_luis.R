source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arizona_st_luis_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("http://www.stlouiscountymn.gov/Portals/0/rpts/SLCJ_Jail_Roster.PDF", fileName, mode = "wb")

endCrawl()