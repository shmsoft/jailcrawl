source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_boone_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("https://www.boonesheriff.com/mobile/roster.php")

moreToLoad <- TRUE
counter <- 1
while(moreToLoad){
  
  Sys.sleep(runif(1,1,3))
  
    
  rsc$findElement("css", "body")$sendKeysToElement(list(key = "end"))
  if(counter == 1){
      
    rsc$findElement(using = "css", "#roster_list > a > span > span.ui-icon.ui-icon-arrow-d.ui-icon-shadow")$clickElement()  
  } else {
      
    clickMe <- tryCatch({
      rsc$findElement(using = "css", paste("#roster_list > a:nth-child(",counter*11,") > span > span.ui-icon.ui-icon-arrow-d.ui-icon-shadow", sep = ""))
    }, error = function(e){
      NA
    })
    
    if(is.na(clickMe)){
      moreToLoad <- FALSE
    } else {
      clickMe$clickElement()
    }
  }
  
  counter <- counter + 1
}

rseleniumGetHTML(rsc, fileName, returnHTML = FALSE, rvestStyle = FALSE)

endCrawl(rsc)