source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Florida_sarasota_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)  # or other browser
rsc <- rsd$client

rsc$navigate("http://cms.revize.com/revize/apps/sarasota/index.php")
rsc$findElement(using = "css", "#dropdownMenuButton")$clickElement()

rseleniumGetHTML(rsc, fileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("body > section > div.dropdown.open > div") %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- trimws(linkz)

linkz <- paste("http://cms.revize.com/revize/apps/sarasota/", linkz, sep = "")
idz <- substr(linkz, regexpr("=", linkz)+1, nchar(linkz))

#a for loop lives in here
getInmateHTML(linkz, idz, fileNameBase = fileName)

endCrawl(rsc = rsc)