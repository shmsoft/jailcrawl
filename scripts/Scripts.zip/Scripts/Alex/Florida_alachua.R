source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Florida_alachua_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://oldweb.circuit8.org/inmatelist.php" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("body") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[c(TRUE, FALSE)]
idz <- substr(linkz, regexpr("=", linkz)+1, nchar(linkz))
linkz <- paste("http://oldweb.circuit8.org/", linkz, sep = "")

getInmateHTML(linkz, idz, fileName)

endCrawl()