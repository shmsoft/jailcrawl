source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_mobile_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rvestGetHTML("http://www.mobileso.com/whos-in-jail/", fileName, returnHTML = FALSE)

endCrawl()