source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_ware_", "http://warecoga.offenderindex.com/")