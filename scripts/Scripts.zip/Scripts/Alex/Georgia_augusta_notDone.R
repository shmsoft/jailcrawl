source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_augusta_", Sys.Date(), ".txt", sep = "")

#startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://appweb2.augustaga.gov/InmateInquiry/AltInmatesOnline.aspx")

rsc$findElement("css", "#btnAccept")$clickElement()
Sys.sleep(runif(1,1,3))

rseleniumGetHTML(rsc = rsc, fileName = fileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("#dlList") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children()


"#dlList"

endCrawl(rsc = rsc)
