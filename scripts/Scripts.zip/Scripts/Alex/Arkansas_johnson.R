source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_johnson_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

passFileName <- paste("jail_crawl/output/", "Arkansas_johnson_", Sys.Date(), "_", 1, ".txt", sep = "")
"https://www.johnsoncosheriff.com/roster.php?grp=20" %>%
  rvestGetHTML(passFileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("#container") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_text() -> numOfInmates
numOfInmates <- numOfInmates[1]
numOfPages <- ceiling(as.numeric(substr(numOfInmates[[1]], regexpr("\\(", numOfInmates[[1]])+1, regexpr("\\)", numOfInmates[[1]])-1))/20)

myHTML %>%
  html_nodes("#container") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz
finalLinkz <- finalLinkz[!is.na(finalLinkz)]

for(i in 2:numPages){
  
  passFileName <- paste("jail_crawl/output/", "Arkansas_johnson_", Sys.Date(), "_", i, ".txt", sep = "")
  passLink <- paste("https://www.johnsoncosheriff.com/roster.php?grp=", i*20, sep = "")
  myHTML <- rvestGetHTML(passLink, passFileName, returnHTML = TRUE)
  
  myHTML %>%
    html_nodes("#container") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("https://www.johnsoncosheriff.com/", finalLinkz, sep = "")

for(j in 1:length(finalLinkz)){
  
  passFileName <- paste("jail_crawl/output/", "Arkansas_johnson_", Sys.Date(), "_", 
                        substr(finalLinkz[j], regexpr("=", finalLinkz[j])+1, nchar(finalLinkz[j])), 
                        ".txt", sep = "")
  passLink <- finalLinkz[j]
  rvestGetHTML(passLink, passFileName, returnHTML = FALSE)
}

endCrawl()