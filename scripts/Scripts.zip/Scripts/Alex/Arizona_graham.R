source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arizona_graham_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.graham.az.gov/DocumentCenter/View/502/Booking-Roster-PDF", fileName, mode = "wb")

endCrawl()