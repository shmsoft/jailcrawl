source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_adams_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("http://www.co.adams.il.us/Jail/inmates/dailypop.pdf", fileName, mode = "wb")

endCrawl()