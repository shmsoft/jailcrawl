source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_newton_", "http://newtoncoga.offenderindex.com")