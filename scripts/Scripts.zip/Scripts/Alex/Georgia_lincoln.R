source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_lincoln_", "http://lincolncoga.offenderindex.com")