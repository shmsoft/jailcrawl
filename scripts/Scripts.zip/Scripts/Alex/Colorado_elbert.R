source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_elbert_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://www.inmateinfo.net/inmateinfo.php?org=ecso")

rseleniumGetHTML(rsc, fileName, TRUE, TRUE) -> myHTML
hm <- rsc$findElement("css", "body > div > article > div:nth-child(4) > h2")$getElementText()[[1]]
numOfInmates <- substr(hm, regexpr(":", hm)+2,nchar(hm))

for(i in 1:numOfInmates){
  
  rsc$findElement("css", paste("body > div > article > div:nth-child(4) > div:nth-child(",i+1,") > div.inmateinfo > span > a", sep = ""))$clickElement()#click
  Sys.sleep(runif(1,1,3))
  passFileName <- paste("jail_crawl/output/", "Colorado_elbert_", Sys.Date(), "_", i, ".txt", sep = "") #pass
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)#get
  rsc$goBack()#back
  Sys.sleep(runif(1,1,3))
}

endCrawl(rsc = rsc)