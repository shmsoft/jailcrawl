source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_san_miguel_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.sanmiguelcountyco.gov/DocumentCenter/View/1343/Current-Inmate-List-?bidId=", fileName, mode = "wb")

endCrawl()