source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_turner_", "http://turnercoga.offenderindex.com")