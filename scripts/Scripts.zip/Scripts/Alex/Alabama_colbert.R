source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_colbert_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#get source code
myHTML <- rvestGetHTML(link = "http://rosterhome.blogspot.com/2017/12/colbert-county-alabama-jail-roster.html",
             fileName = fileName,
             returnHTML = TRUE)

myHTML %>%
  html_nodes("#post-body-2771420771252554321 > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> firstLinkz

myHTML %>%
  html_nodes("#post-body-2771420771252554321 > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> hm
#not sure why this is necessary...not picking up correctly


endCrawl()