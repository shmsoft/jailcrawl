source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://lcso.leeco.us/DCN/inmates", "Georgia_lee_")