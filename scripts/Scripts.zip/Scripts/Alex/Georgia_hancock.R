source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_hancock_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://activeinmates.hancocksheriff.org/")

rseleniumGetHTML(rsc, fileName, FALSE, FALSE)

trimws(rsc$findElement("css", "#frm > table:nth-child(145) > tbody > tr:nth-child(4) > td.PageStatsValue")$getElementText()[[1]]) -> numOfInmates
numOfInmates <- as.numeric(numOfInmates)

for(j in 1:length(numOfInmates)){
  
  rsc$findElement("css", paste("#frm > div:nth-child(",i+11,") > div > div > table > tbody > tr:nth-child(1) > td > table > tbody > tr > td.ResultName2 > div:nth-child(1)", sep = ""))$clickElement()
  Sys.sleep(1,1,6)
  passFileName <- paste("jail_crawl/output/", "Georgia_hancock_", Sys.Date(),"_", i, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)
  rsc$findElement("css", "#divDetail > div.DetailHeaderCommand > a")$clickElement()
}

endCrawl(rsc = rsc)