source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_tehama_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rvestGetHTML("http://www.tehamaso.org/inmates/ICURRENT.HTM",fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("body") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[!is.na(linkz)]
idz <- substr(linkz, 5,8)
linkz <- paste("http://www.tehamaso.org/inmates/", linkz, sep = "")

for(j in 1:length(linkz)){
  
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "California_tehama_", Sys.Date(), "_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}