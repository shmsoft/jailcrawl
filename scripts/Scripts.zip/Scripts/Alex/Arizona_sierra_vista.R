source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arizona_sierra_vista_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.cochise.az.gov/sites/default/files/sheriff/public_info/inmate_list.pdf", fileName, mode = "wb")

endCrawl()