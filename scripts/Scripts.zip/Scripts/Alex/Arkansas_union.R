source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_union_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

finalLinkz <- c()

for(i in 1:26){
  
  passLink <- paste("http://jail.unioncountysheriff.net:3500/ois/inmatesnow.aspx?id=", LETTERS[i], sep = "")
  passFileName <- paste("jail_crawl/output/", "Arkansas_union_", Sys.Date(),"_", LETTERS[i], ".txt", sep = "")
  myHTML <- rvestGetHTML(passLink, passFileName, TRUE)
  
  myHTML %>%
    html_nodes("#divvar") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("http://jail.unioncountysheriff.net:3500/ois/", finalLinkz, sep = "")
idz <- substr(finalLinkz, regexpr("=", finalLinkz), nchar(finalLinkz))

for(j in 1:length(finalLinkz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_union_", Sys.Date(),"_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE, FALSE)
}

endCrawl()