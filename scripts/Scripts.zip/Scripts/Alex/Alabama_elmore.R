source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_elmore_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

#go to page and get the number of inmates
rsc$navigate("http://jailroster.elmorecounty.org:81/")
numOfInmates <- rsc$findElement(using = "css", "#ctl00_ContentPlaceHolder1_inmateTotal")$getElementText()[[1]]
numOfInmates <- as.numeric(substr(numOfInmates, regexpr(":", numOfInmates)+2, nchar(numOfInmates)))

#they display 15 per page, need to know how many times to click
numOfPages <- ceiling(numOfInmates / 15)
finalLinkz <- c()
#commenting out getting their names because using IDs whenever possible for files
#finalNamez <- c()

for(i in 1:numOfPages){
  
  newFileName <- paste(substr(fileName, 1, nchar(fileName) - 4), "_", i, ".txt", sep = "")
  
  #write page html to file
  myHTML <- rseleniumGetHTML(rsc, fileName, returnHTML = TRUE, rvestStyle = FALSE)
  
  #getting the links for each inmate's page
  myHTML$getElementAttribute("innerHTML")[[1]] %>%
    read_html() %>%
    html_nodes("#ctl00_ContentPlaceHolder1_GV1") %>%
    html_children() %>%
    html_children() %>%
    html_children() -> info
  info %>%
    html_children() %>%
    html_attr("href") -> linkz
  
  # info %>%
  #   html_text() -> namez
  # namez <- namez[1:(length(namez)-1)]
  # finalNamez <- c(finalNamez, namez)
  
  #keeping the master list of inmate linkz
  finalLinkz <- c(finalLinkz, linkz)
  
  if(i != numOfPages){
    
    rsc$findElement(using = "css", paste("#ctl00_ContentPlaceHolder1_GV1 > tbody > tr.paging > td > table > tbody > tr > td:nth-child(",i+1,") > a", sep = ""))$clickElement()
  }
  
  Sys.sleep(runif(1,0,2))
}

finalLinkz <- finalLinkz[!is.na(finalLinkz)]
finalLinkz <- paste("http://jailroster.elmorecounty.org:81/", finalLinkz, sep = "")
finalIDz <- substr(finalLinkz, 59, nchar(finalLinkz))

#visiting each inmate now
for(j in 1:length(finalLinkz)){
  
  rsc$navigate(finalLinkz[j])
  #some prisoners have multiple pages of records
  #if only one page, not element possible so R will throw error
  numOfPages <- tryCatch({
    
    rsc$findElement(using = "css", "#ctl00_ContentPlaceHolder1_GV1 > tbody > tr:nth-child(7) > td > table > tbody > tr")$getElementText()[[1]]
  }, error = function(e){
    
    "nothing to see here"
  })
  
  #getting number of pages now
  if(numOfPages != "nothing to see here"){
    
    spaces <- gregexpr(" ", numOfPages)[[1]][1]
    numOfPages <- as.numeric(substr(numOfPages, spaces[length(spaces)] + 1, nchar(numOfPages)))
  } else {
    
    numOfPages <- 1
  }
  
  #pulling down the data for each page of the inmate
  for(k in 1:numOfPages){
    
    newFileName <- paste(substr(fileName, 1, nchar(fileName) - 4), "_sub_", finalIDz[j], "_", k, ".txt", sep = "")
    rseleniumGetHTML(rsc = rsc, fileName = newFileName, returnHTML = FALSE, rvestStyle = FALSE)
    if(k != numOfPages){
      
      rsc$findElement(using = "css", paste("#ctl00_ContentPlaceHolder1_GV1 > tbody > tr:nth-child(7) > td > table > tbody > tr > td:nth-child(",k+1,") > a"))$clickElement()
    }
    Sys.sleep(runif(1,0,2))
  }
}

endCrawl(rsc = rsc)