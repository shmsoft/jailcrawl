library("rvest")
library("magrittr")
library("RSelenium")

rm(list = ls())
closeAllConnections()

options(stingsAsFactors = FALSE)

#startCrawl will set up log files and post the time
startCrawl <- function(fileName){
  
  sink(
    file = file(paste(getwd(), "/", substr(fileName, 1, nchar(fileName) - 4), "_outputLog.txt", sep = ""), open = "wt"),
    append=TRUE,
    type="output"
  )
  
  sink(
    file = file(paste(getwd(), "/", substr(fileName, 1, nchar(fileName) - 4), "_errorLog.txt", sep = ""), open = "wt"),
    append=TRUE,
    type="message"
  )
  
  print("####BEGIN CRAWLER DIALOGUE####")
  print(paste("Begin Crawl: ", Sys.time(), sep = ""))
}

#endCrawl will post end time and reset the sink
endCrawl <- function(rsc = NA){
  
  if(!is.na(rsc)){
    
    rsc$close()
  }
  
  print(paste("Completed Crawl: ", Sys.time(), sep = ""))
  print("####END CRAWLER DIALOGUE####")
  
  sink()
  closeAllConnections()
}

rvestGetHTML <- function(link, fileName, returnHTML){
  
  if(returnHTML){
    
    link %>%
      read_html() -> myHTML
    myHTML %>%
      write_xml(file=fileName)
    return(myHTML)
  } else {
    
    link %>%
      read_html() %>%
      write_xml(file=fileName)  
  }
}

rseleniumGetHTML <- function(rsc, fileName, returnHTML, rvestStyle){
  
  if(returnHTML){
    
    if(rvestStyle){
      
      myHTML <- rsc$findElement(using = 'tag name',"html")$getElementAttribute("innerHTML")[[1]]
      myHTML %>%
        write.table(fileName, row.names = FALSE, col.names = FALSE, quote = FALSE)
      myHTML %>%
        read_html() -> myHTML
    } else {
      
      myHTML <- rsc$findElement(using = 'tag name',"html")
      myHTML$getElementAttribute("innerHTML")[[1]] %>%
        write.table(fileName, row.names = FALSE, col.names = FALSE, quote = FALSE)
    }
    
    return(myHTML)
  } else {
    
    myHTML <- rsc$findElement(using = 'tag name',"html")
    myHTML$getElementAttribute("innerHTML")[[1]] %>%
      write.table(fileName, row.names = FALSE, col.names = FALSE, quote = FALSE)
  }
}

getInmateHTML <- function(linkz, idz, fileNameBase){
  
  print("getting inmate html")
  for(j in 1:length(idz)){
    
    passLink <- linkz[j]
    passFileName <- paste(substr(fileNameBase, 1, regexpr("\\.", fileNameBase)-1), "_", idz[j], ".txt", sep = "")
    rvestGetHTML(passLink, passFileName, FALSE)
  }
}

offenderIndexGetHTML <- function(fileNameBase, thisLink){
  
  fileName <- paste("jail_crawl/output/", fileNameBase, Sys.Date(), ".txt", sep = "")
  
  startCrawl(fileName)
  
  rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
  rsc <- rsd$client
  
  rsc$navigate(thisLink)
  Sys.sleep(runif(1,4,8))
  
  numOfInmates <- rsc$findElement(using = "css", "#allInmatesGrid > div.k-pager-wrap.k-grid-pager.pagerTop.k-widget > span")$getElementText()
  numOfInmates <- substr(numOfInmates, regexpr("of ", numOfInmates)+3, nchar(numOfInmates))
  numOfInmates <- as.numeric(substr(numOfInmates, 1, regexpr(" ", numOfInmates)-1))
  
  numOfPages <- ceiling(numOfInmates / 10)
  
  for(i in 1:numOfPages){
    
    passFileName <- paste("jail_crawl/output/", fileNameBase, Sys.Date(), "_", i, ".txt", sep = "")
    rseleniumGetHTML(rsc, passFileName, returnHTML = TRUE, rvestStyle = FALSE)
    if(i != numOfPages){
      
      rsc$findElement(using = "css", "#allInmatesGrid > div.k-pager-wrap.k-grid-pager.pagerTop.k-widget > a:nth-child(4)")$clickElement()
    }
    Sys.sleep(runif(1,4,8))
  }
  
  endCrawl(rsc = rsc)
}

dcnGetHTML <- function(thisLink, fileNameTextOnly){
  
  fileName <- paste("jail_crawl/output/", fileNameTextOnly, Sys.Date(), ".txt", sep = "")
  
  startCrawl(fileName)
  
  #start selenium
  rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)  # or other browser
  rsc <- rsd$client
  
  rsc$navigate(thisLink)
  
  #click on the table setting
  rsc$findElement(using = 'css','#gvInmates_DXPagerBottom_DDBImg')$clickElement()
  Sys.sleep(runif(1,0,2))
  #view all
  rsc$findElement(using = 'css','#gvInmates_DXPagerBottom_PSP_DXI5_T')$clickElement()
  Sys.sleep(runif(1,4,8))
  
  myHTML <- rseleniumGetHTML(rsc = rsc, fileName = fileName, returnHTML = TRUE, rvestStyle = TRUE)
  
  myHTML %>%
    html_nodes("#gvInmates_DXMainTable") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  linkz <- linkz[linkz != "javascript:;"]
  
  linkStem <- if(regexpr("dcn/inmate", thisLink) < 0){
    
    substr(thisLink, 1, regexpr("DCN/inmate", thisLink)-2)
  } else {
    
    substr(thisLink, 1, regexpr("dcn/inmate", thisLink)-2)
  }

  linkz <- paste(linkStem, linkz, sep = "")
  idz <- substr(linkz, regexpr("=", linkz)+1, regexpr("&bid=", linkz)-1)
  
  getInmateHTML(linkz, idz, fileName)
  
  endCrawl(rsc = rsc)
}