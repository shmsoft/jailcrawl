source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_chilton_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)  # or other browser
rsc <- rsd$client

# navigate to page
rsc$navigate("http://jail.chiltoncountyso.org/dcn/inmates")

#click on table settings
rsc$findElement(using = 'css selector',"#gvInmates_DXPagerBottom_DDBImg")$clickElement()
Sys.sleep(runif(1,0,2))
#view all
rsc$findElement(using = 'css selector',"#gvInmates_DXPagerBottom_PSP_DXI5_T > span")$clickElement()

#get html
myHTML <- rseleniumGetHTML(rsc = rsc, fileName = fileName, returnHTML = TRUE, rvestStyle = TRUE)

myHTML %>%
  html_nodes("#gvInmates_DXMainTable") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[!is.na(linkz)]
linkz <- linkz[linkz != "javascript:;"]
linkz <- paste("http://jail.chiltoncountyso.org", linkz, sep = "")

for(j in 1:length(linkz)){
  
  rsc$navigate(linkz[j])
  Sys.sleep(runif(1,0,2))
  passFileName <- paste("jail_crawl/output/", "Alabama_coosa_", Sys.Date(),
                        "_", substr(linkz[j], regexpr("=", linkz[j])+1, regexpr("&bid=", linkz[j])-1),
                        ".txt", sep = "")
  rseleniumGetHTML(rsc = rsc, fileName = passFileName, return = FALSE, rvestStyle = FALSE)
}

rsc$close()
endCrawl()