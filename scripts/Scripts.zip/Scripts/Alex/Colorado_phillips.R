source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_phillips_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://phillips.pixelpowerhaus.net/")

numOfInmates <- rsc$findElement("css", "#inmates_info")$getElementText()[[1]]

numOfInmates <- as.numeric(substr(numOfInmates, regexpr("of ", numOfInmates)+3, regexpr(" entries", numOfInmates)-1))
numOfClicks <- ceiling(numOfInmates / 25)-1

passFileName <- paste("jail_crawl/output/", "Colorado_phillips_", Sys.Date(), "_", 1, ".txt", sep = "")
rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML

if(numOfClicks > 0){
  
  for(i in 1:numOfClicks){
    
    rsc$findElement("css", "#inmates_next")$clickElement()
    
    passFileName <- paste("jail_crawl/output/", "Colorado_phillips_", Sys.Date(), "_", i+1, ".txt", sep = "")
    rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML
    
  }
}

endCrawl(rsc)