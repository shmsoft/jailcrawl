source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_houston_", Sys.Date(), ".txt", sep = "")

#startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://online.houstoncountyga.org:8011/mrcjava/servlet/MRCPUBLIC.I00030s")
Sys.sleep(runif(1,3,5))

rsc$findElement("css", "#mrc_main_table > tr:nth-child(1) > th > input.mrcinput")$clickElement()
rsc$findElement("css", "#mrc_main_table > tr:nth-child(1) > th > input.mrcinput")$sendKeysToActiveElement(list("000", key = "enter"))
Sys.sleep(runif(1,5,8))

rseleniumGetHTML(rsc, fileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("#mrcMainContent > table > tbody > tr > td > form:nth-child(2) > table.collapse") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[!is.na(linkz)]

idz <- substr(linkz, regexpr("NO=", linkz) + 3, nchar(linkz))
linkz <- paste("http://online.houstoncountyga.org:8011/mrcjava/servlet/", linkz, sep = "")

getInmateHTML(linkz, idz, fileName)

endCrawl(rsc = rsc)