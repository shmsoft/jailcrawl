source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Tennessee_mcminn_", "http://mcminncotn.offenderindex.com/")