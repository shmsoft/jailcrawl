source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://24.106.185.194/dcn/inmates", "South_Carolina_darlington_")