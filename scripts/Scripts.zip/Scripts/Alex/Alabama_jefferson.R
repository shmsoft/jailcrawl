source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_jefferson_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.co.jefferson.tx.us/Sheriff/content/documents/inmate/CURRENTINMATES.PDF", fileName, mode = "wb")

endCrawl()