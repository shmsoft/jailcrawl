source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_baldwin_", Sys.Date(), ".txt", sep = "")
startCrawl(fileName)

#load selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)  # or other browser
rsc <- rsd$client

# navigate to page
rsc$navigate("http://bcsonline.co.baldwin.al.us/smartweb/jail.aspx")
Sys.sleep(runif(1,0,2))

#click the load more button
rsc$findElement(using = 'css selector',"#LoadMoreButton > p:nth-child(1)")$clickElement()

#get HTML
myHTML <- rsc$findElement(using = 'tag name',"html")
myHTML$getElementAttribute("innerHTML")[[1]] %>%
  write.table(fileName, row.names = FALSE, col.names = FALSE, quote = FALSE)

endCrawl(rsc = rsc)