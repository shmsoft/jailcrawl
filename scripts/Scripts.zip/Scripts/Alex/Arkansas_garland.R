source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_garland_", Sys.Date(), ".txt", sep = "")

#startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

#go to page and get the number of inmates
rsc$navigate("http://findtheinmate.com/garland")
Sys.sleep(runif(1,5,7))

myHTML <- rseleniumGetHTML(rsc, fileName, TRUE, TRUE)

myHTML %>%
  html_nodes("#InmateList") %>%
  html_children() %>%
  html_children() %>%
  length() -> numOfInmates

numOfInmates <- numOfInmates - 1

for(j in 1:numOfInmates){

  passFileName <- paste("jail_crawl/output/", "Arkansas_garland_", Sys.Date(), "_", j, ".txt", sep = "")
  rsc$findElement(using = "css", paste("#InmateList > tbody > tr:nth-child(",j+1,")", sep = ""))$clickElement()
  Sys.sleep(runif(1,1,3))
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)
  Sys.sleep(runif(1,1,3))
  rsc$goBack()
}

endCrawl(rsc = rsc)