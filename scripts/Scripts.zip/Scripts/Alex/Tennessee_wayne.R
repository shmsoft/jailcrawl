source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://69.131.167.234:8080/DCN/inmates", "Tennessee_wayne_")