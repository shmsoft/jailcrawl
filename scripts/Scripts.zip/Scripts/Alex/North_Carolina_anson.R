source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://www.ansonsheriff.com/dcn/inmates", "North_Carolina_anson_")