source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Wisconsin_price_", Sys.Date(), ".txt", sep = "")
startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

#go to page
rsc$navigate("https://www.co.price.wi.us/664/Current-Inmate-List")
passFileName <- paste("jail_crawl/output/", "Wisconsin_price_", Sys.Date(),"_1", ".txt", sep = "")
myHTML <- rseleniumGetHTML(rsc = rsc, fileName = fileName, returnHTML = TRUE, rvestStyle = TRUE)

myHTML %>%
  html_nodes("#divTabbed7f6f7d89-ccc3-4467-9a25-5d4200caa341 > ol") %>%
  html_children() -> numOfClicks
numOfClicks <- length(numOfClicks) - 1
for(i in 1:numOfClicks){
  
  
  rsc$findElement(using = "css", paste("#divTabbed7f6f7d89-ccc3-4467-9a25-5d4200caa341 > ol > li:nth-child(",i + 1,") > a > span", sep = ""))$clickElement()
  Sys.sleep(runif(1,0,2))
  passFileName <- passFileName <- paste("jail_crawl/output/", "Wisconsin_price_", Sys.Date(),"_", i+1, ".txt", sep = "")
  rseleniumGetHTML(rsc = rsc, fileName = passFileName, returnHTML = FALSE, rvestStyle = FALSE)
}

rsc$close()
endCrawl()