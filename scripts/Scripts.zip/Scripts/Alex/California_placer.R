source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_placer_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("http://www.placer.ca.gov//Jail/jailpdf/InCustody.pdf", fileName, mode = "wb")

endCrawl()