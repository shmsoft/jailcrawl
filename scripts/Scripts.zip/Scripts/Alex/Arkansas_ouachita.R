source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_ouachita_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

finalLinkz <- c()

for(i in 1:26){
  
  passLink <- paste("http://inmates.ouachitacountysheriff.org/index.aspx?id=", LETTERS[i], sep ="")
  passFileName <- paste("jail_crawl/output/", "Arkansas_ouachita_", Sys.Date(), "_", LETTERS[i], ".txt", sep = "")
  myHTML <- rvestGetHTML(passLink, passFileName, TRUE)
  
  myHTML %>%
    html_nodes("#ctl01") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("onclick") -> linkz
  linkz <- linkz[!is.na(linkz)]
  linkz <- paste("http://inmates.ouachitacountysheriff.org/", substr(linkz, regexpr("details", linkz), nchar(linkz)-2), sep = "")
  finalLinkz <- c(finalLinkz, linkz)
  
}

for(j in 1:length(finalLinkz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_ouachita_", Sys.Date(), "_", j, ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()