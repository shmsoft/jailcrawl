source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_tift_", "http://tiftcoga.offenderindex.com")