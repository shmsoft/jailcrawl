source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_marion_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rvestGetHTML("http://mcsomo.com/current-inmates/", fileName, FALSE)

endCrawl()