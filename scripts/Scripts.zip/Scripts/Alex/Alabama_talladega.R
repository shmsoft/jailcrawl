source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_talladega_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)  # or other browser
rsc <- rsd$client

rsc$navigate("http://97.82.2.131/dcn/inmates")

#click on the table setting
rsc$findElement(using = 'css','#gvInmates_DXPagerBottom_DDBImg')$clickElement()
Sys.sleep(runif(1,0,2))
#view all
rsc$findElement(using = 'css','#gvInmates_DXPagerBottom_PSP_DXI5_T')$clickElement()
Sys.sleep(runif(1,4,8))

myHTML <- rseleniumGetHTML(rsc = rsc, fileName = fileName, returnHTML = TRUE, rvestStyle = TRUE)

myHTML %>%
  html_nodes("#gvInmates_DXMainTable") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[!is.na(linkz)]
linkz <- linkz[linkz != "javascript:;"]
linkz <- paste("http://97.82.2.131", linkz, sep = "")

for(j in 1:length(linkz)){
  
  rsc$navigate(linkz[j])
  Sys.sleep(runif(1,0,2))
  passFileName <- paste("jail_crawl/output/", "Alabama_talladega_", Sys.Date(),
                        "_", substr(linkz[j], regexpr("=", linkz[j])+1, regexpr("&bid=", linkz[j])-1),
                        ".txt", sep = "")
  rseleniumGetHTML(rsc = rsc, fileName = passFileName, returnHTML = FALSE, rvestStyle = FALSE)
}

endCrawl(rsc = rsc)
