source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_washington_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"https://www.so.washington.ar.us/res/DAlphaRoster.aspx" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("#Results > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- paste("https://www.so.washington.ar.us/res/", linkz, sep = "")
idz <- substr(linkz, regexpr("=", linkz)+1, nchar(linkz))

for(j in 1:length(linkz)){
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_washington_", Sys.Date(),"_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()