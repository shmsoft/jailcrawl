source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Florida_osceola_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("https://arrests.pascosheriff.org/arrests/default.aspx")
passFileName <- paste("jail_crawl/output/", "Florida_pasco_", Sys.Date(),"_", 1, ".txt", sep = "")
rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("#GridView1") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
finalLinkz <- linkz[9:(length(linkz)-1)]

myHTML %>%
  html_nodes("#GridView1 > tbody > tr:nth-child(22) > td > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  length() -> numOfPages
numOfPages <- numOfPages - 1

for(i in 1:numOfPages){
  
  rsc$findElement("css", paste("#GridView1 > tbody > tr:nth-child(22) > td > table > tbody > tr > td:nth-child(",i+1,") > a", sep = ""))$clickElement()
  passFileName <- paste("jail_crawl/output/", "Florida_osceola_", Sys.Date(),"_", i+1, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML
  myHTML %>%
    html_nodes("#GridView1") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  finalLinkz <- c(finalLinkz, linkz[9:(length(linkz)-1)])
}

idz <- substr(finalLinkz, regexpr("=", finalLinkz)+1, nchar(finalLinkz))
finalLinkz <- paste("https://arrests.pascosheriff.org/arrests/", finalLinkz, sep = "")
for(j in 1:length(idz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste("jail_crawl/output/", "Florida_pasco_", Sys.Date(),"_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl(rsc = rsc)