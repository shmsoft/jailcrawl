source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_haralson_", "http://haralsoncoga.offenderindex.com")