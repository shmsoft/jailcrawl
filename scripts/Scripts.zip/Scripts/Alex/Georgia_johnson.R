source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_johnson_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file(url = "http://johnsonso.com/wp-content/plugins/pdfjs-shortcode/web/viewer.php?file=http://johnsonso.com/wp-content/uploads/sites/10/Jail-Population-Report.pdf&download=true&print=true&openfile=true", destfile = fileName, mode = "wb")

endCrawl()