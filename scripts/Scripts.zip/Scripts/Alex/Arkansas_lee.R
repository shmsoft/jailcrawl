source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_lee_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://www.leecosheriff.com/Inmates/ICURRENT.HTM" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("body") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz
linkz <- linkz[!is.na(linkz)]
idz <- substr(linkz,4,8)
linkz <- paste("http://www.leecosheriff.com/Inmates/", linkz, sep = "")

for(j in 1:length(linkz)){
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_lee_", Sys.Date(), "_", idz[j],".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()