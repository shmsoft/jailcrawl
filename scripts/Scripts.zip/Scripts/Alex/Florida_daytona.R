source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Florida_daytona_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://www.daytonamugshots.com/")

numOfClicks <- rsc$findElement("css", "#form1 > div.sliderWrapper > div.headerText > div.displaying")$getElementText()[[1]]

numOfClicks <- as.numeric(substr(numOfClicks, regexpr("of ", numOfClicks)+3, nchar(numOfClicks)))-1

passFileName <- paste("jail_crawl/output/", "Florida_daytona_", Sys.Date(), "_", 1, ".txt", sep = "")
rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML
myHTML %>%
  html_nodes("#mugs") %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz

for(i in 1:numOfClicks){
  
  rsc$findElement("css", "#ContentPlaceHolder1_lbtnNext")$clickElement()
  Sys.sleep(runif(1,1,3))
  passFileName <- paste("jail_crawl/output/", "Florida_daytona_", Sys.Date(), "_",i+1, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML
  myHTML %>%
    html_nodes("#mugs") %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  finalLinkz <- c(finalLinkz, linkz)
}

idz <- substr(finalLinkz, regexpr("=", finalLinkz)+1, nchar(finalLinkz))
finalLinkz <- paste("http://www.daytonamugshots.com/", finalLinkz, sep = "")

for(j in 1:length(finalLinkz)){
  
  passFileName <- paste("jail_crawl/output/", "Florida_daytona_", Sys.Date(), "_",idz[j], ".txt", sep = "")
  passLink <- finalLinkz[j]
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl(rsc = rsc)