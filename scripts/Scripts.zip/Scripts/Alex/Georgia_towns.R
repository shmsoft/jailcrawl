source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_towns_", "http://townscoga.offenderindex.com")