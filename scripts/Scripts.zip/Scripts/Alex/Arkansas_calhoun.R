source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_calhoun_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://www.calcoso.org/divisions-jail-inmate-roster/" %>%
  rvestGetHTML(fileName = fileName, returnHTML = TRUE) %>%
  html_nodes("#myTable") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz

linkz <- paste("http://www.calcoso.org", linkz, sep = "")
for(j in 1:length(linkz)){
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_calhoun_", Sys.Date(), "_", substr(linkz[j], regexpr("\\?", linkz[j])+1,nchar(linkz[j])), ".txt", sep = "")
  
  passLink <- gsub(" ", "%20", passLink)
  passFileName <- gsub(" ", "%20", passFileName)
  
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()