source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_fayette_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#get source code
passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_1", ".txt", sep = "")
myHTML <- rvestGetHTML(link = "http://www.fayetteso.com/roster.php?grp=20",
                       fileName = passFileName,
                       returnHTML = TRUE)

#get the number of pages there are
#they display 20 inmates per page
myHTML %>%
  html_nodes("#container > div.table > main > div:nth-child(2) > table") %>%
  html_children() -> tbl
tbl[1] %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_text() -> tbl
#rounding up the quotient of (inmates / 20)
numOfPages <- ceiling(as.numeric(substr(tbl[1], regexpr("\\(", tbl)+1, regexpr("\\)", tbl)-1)) / 20)

myHTML %>%
  html_nodes("#container > div.table > main > div:nth-child(2) > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz
finalLinkz <- finalLinkz[!is.na(finalLinkz)]

for(i in 2:numOfPages){
  
  passLink <- paste("http://www.fayetteso.com/roster.php?grp=", i*20, sep = "")
  passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_", i, ".txt", sep = "")
  myHTML <- rvestGetHTML(link = passLink,
                         fileName = passFileName,
                         returnHTML = TRUE)
  
  myHTML %>%
    html_nodes("#container > div.table > main > div:nth-child(2) > table") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("http://www.fayetteso.com/", finalLinkz, sep = "")

for(j in 1:length(finalLinkz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_",
                        substr(finalLinkz[j], regexpr("=", finalLinkz[j])+1, nchar(finalLinkz[j]))
                        , ".txt", sep = "")
  rvestGetHTML(link = passLink, fileName = passFileName, returnHTML = FALSE)
}

endCrawl()