source("jail_crawl/crawlSteps.R")

dcnGetHTML("https://webapps.moorecountync.gov/dcn/inmates", "North_Carolina_moore_")