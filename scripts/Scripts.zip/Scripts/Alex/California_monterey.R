source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_monterey_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

#go to page and get the number of inmates
rsc$navigate("https://www.montereysheriff.org/inmates/")

rsc$findElement(using = "css", "#tablepress-16_length > label > select")$clickElement()
rsc$sendKeysToActiveElement(
  list(key = 'down_arrow', key = 'down_arrow', key = 'down_arrow', key = 'enter')
)

numOfInmates <- rsc$findElement("css", "#tablepress-16_info")$getElementText()[[1]]
numOfInmates <- as.numeric(substr(numOfInmates, regexpr("of ", numOfInmates)+3, regexpr("entries", numOfInmates)-2))
numOfPages <- ceiling(numOfInmates / 100)


passFileName <- paste("jail_crawl/output/", "California_monterey_", Sys.Date(), "_1", ".txt", sep = "")
rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)

for(i in 2:numOfPages){
  
  rsc$findElement("css", "#tablepress-16_next")$clickElement()
  Sys.sleep(runif(1,3,5))
  passFileName <- paste("jail_crawl/output/", "California_monterey_", Sys.Date(), "_", i, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)
}

endCrawl(rsc)