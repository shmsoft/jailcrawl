source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_pulaski_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#start selenium
rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

#go to page and get the number of inmates
rsc$navigate("http://findtheinmate.com/gsapdfs/15334035612824.VERIFY.18479.62762066.html")
Sys.sleep(runif(1,3,5))
myHTML <- rseleniumGetHTML(rsc,fileName,TRUE,TRUE)

myHTML %>%
  html_nodes("#InmateList") %>%
  html_children() %>%
  html_children() %>%
  length() -> numOfClicks
numOfClicks <- numOfClicks - 1

for(j in 1:numOfClicks){
  
  Sys.sleep(runif(1,1,3))
  rsc$findElement(using = "css", paste("#InmateList > tbody > tr:nth-child(",j+1,")", sep = ""))$clickElement()
  Sys.sleep(runif(1,1,3))
  passFileName <- paste("jail_crawl/output/", "Arkansas_pulaski_", Sys.Date(), "_", j,".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)
  Sys.sleep(runif(1,1,3))
  rsc$findElement("css", "body > div > p:nth-child(1) > a:nth-child(1)")$clickElement()
}


endCrawl(rsc)