source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_douglas_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://www.co.douglas.mn.us/dc/inmate-roster.aspx")

passFileName <- paste("jail_crawl/output/", "Colorado_douglas_", Sys.Date(), "_", 1, ".txt", sep = "")
myHTML <- rseleniumGetHTML(rsc, passFileName, TRUE, TRUE)
myHTML %>%
  html_nodes("#cphBody_cphCenter_ctl01_paginationtop > div:nth-child(2)") %>%
  html_children() %>%
  length() -> numOfClicks

for(i in 2:numOfClicks){
  
  rsc$findElement("css", paste("#cphBody_cphCenter_ctl01_paginationtop_paginationtop_lb", i, sep = ""))$clickElement()
  passFileName <- paste("jail_crawl/output/", "Colorado_douglas_", Sys.Date(), "_", i, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, FALSE, FALSE)
}

endCrawl(rsc = rsc)