source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arizona_greenlee_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.co.greenlee.az.us/sheriff/Arrest%20Log-Jan%202018.pdf", fileName, mode = "wb")

endCrawl()