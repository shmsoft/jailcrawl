source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_dougherty_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://www.walb.com/story/16505739/dougherty-co-jail-bookings" %>%
  rvestGetHTML(fileName, FALSE)

endCrawl()