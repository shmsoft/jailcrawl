source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_jackson_", "http://jacksoncoga.offenderindex.com/")