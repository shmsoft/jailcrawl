source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://dcn.leecountync.gov/dcn/inmates", "North_Carolina_lee_")