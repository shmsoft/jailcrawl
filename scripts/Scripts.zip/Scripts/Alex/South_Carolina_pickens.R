source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://www.pickenscodetention.org/dcn/inmates", "South_Carolina_pickens_")