source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_hall_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://www.hallcounty3.org/sheriff/jailpop/jailpop.html" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

endCrawl()