source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_searcy_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rvestGetHTML(link = "http://searcycountysheriff.org/jail-roster", fileName, FALSE)

endCrawl()