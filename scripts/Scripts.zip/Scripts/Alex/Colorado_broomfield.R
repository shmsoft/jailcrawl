source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_broomfield_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://egov.broomfield.org/Police/Detention/ActiveBooking/ActiveBooking.pdf", fileName, mode = "wb")

endCrawl()