source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_yuma_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://docs.google.com/file/d/0B0yN-as7CedNNlZJTkVUbGM3aTQ/edit", fileName, mode = "wb")

endCrawl()