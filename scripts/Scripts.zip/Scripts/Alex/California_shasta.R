source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_shasta_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("https://apps.co.shasta.ca.us/In_Custody/incustody.aspx")
Sys.sleep(runif(1,2,4))

if(rsc$getCurrentUrl()[[1]] == "https://apps.co.shasta.ca.us/In_Custody/incustody_disclaimer.aspx"){
  
  print("quitting disclaimer")
  rsc$findElement(using = "css", "#btnAgree")$clickElement()
  Sys.sleep(runif(1,2,4))
}

rseleniumGetHTML(rsc, fileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("#listing > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> linkz

linkz <- paste("https://apps.co.shasta.ca.us/In_Custody/", linkz, sep = "")
idz <- substr(linkz, regexpr("=", linkz)+1, nchar(linkz))

for(j in 1:length(linkz)){
  
  
  passLink <- linkz[j]
  passFileName <- paste("jail_crawl/output/", "California_shasta_", Sys.Date(), "_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl(rsc = rsc)