source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "California_yuba_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://sheriff.co.yuba.ca.us/services/inmate_list.aspx")
Sys.sleep(runif(1,2,4))

if(rsc$getCurrentUrl()[[1]] == "http://sheriff.co.yuba.ca.us/Inmate.aspx"){
  
  print("quitting disclaimer")
  rsc$findElement(using = "css", "#lnkIAgree")$clickElement()
  Sys.sleep(runif(1,2,4))
}

passFileName <- paste("jail_crawl/output/", "California_yuba_", Sys.Date(),"_", 1, ".txt", sep = "")
rseleniumGetHTML(rsc, fileName = passFileName, TRUE, TRUE) -> myHTML

myHTML %>%
  html_nodes("#grImateListing > tbody") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  length() -> numOfPages

myHTML %>%
  html_nodes("#grImateListing > tbody") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz
finalLinkz <- finalLinkz[!is.na(finalLinkz)]

for(i in 2:numOfPages){
  
  rsc$findElement(using = "css", paste("#grImateListing > tbody > tr:nth-child(42) > td > table > tbody > tr > td:nth-child(",i,") > a", sep = ""))$clickElement()
  passFileName <- paste("jail_crawl/output/", "California_yuba_", Sys.Date(),"_", i, ".txt", sep = "")
  Sys.sleep(runif(1,1,3))
  rseleniumGetHTML(rsc, passFileName, TRUE, TRUE) -> myHTML
  myHTML %>%
    html_nodes("#grImateListing > tbody") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("http://sheriff.co.yuba.ca.us/services/", finalLinkz, sep = "")
idz <- substr(finalLinkz, regexpr("=", finalLinkz)+1, nchar(finalLinkz))

for(j in 1:length(idz)){
  
  passFileName <- paste("jail_crawl/output/", "California_yuba_", Sys.Date(),"_", idz[j], ".txt", sep = "")
  passLink <- finalLinkz[j]
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()