source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Connecticut_hartford_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("http://www.hartford.gov/images/police/ArrestLogs/blotter.pdf", fileName, mode = "wb")

endCrawl()