source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Alabama_greene_", "http://greenecoga.offenderindex.com/")