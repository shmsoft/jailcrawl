source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_clarke_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://enigma.accgov.com/photo/jailcurrent.asp" %>%
  rvestGetHTML(fileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("body > table") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("onclick") -> linkz
linkz <- substr(linkz, regexpr("detailsNEW", linkz), regexpr(",", linkz)-2)
linkz <- paste("http://enigma.accgov.com/photo/", linkz, sep = "")
idz <- substr(linkz, regexpr("?id", linkz)+4, regexpr("&bid", linkz)-1)

getInmateHTML(linkz, idz, fileName)

endCrawl()