source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_brooks_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

rsd <- RSelenium::rsDriver(browser = "chrome", verbose = FALSE)
rsc <- rsd$client

rsc$navigate("http://brookscoga.offenderindex.com/")
Sys.sleep(runif(1,4,8))

numOfInmates <- rsc$findElement(using = "css", "#allInmatesGrid > div.k-pager-wrap.k-grid-pager.pagerTop.k-widget > span")$getElementText()
numOfInmates <- substr(numOfInmates, regexpr("of ", numOfInmates)+3, nchar(numOfInmates))
numOfInmates <- as.numeric(substr(numOfInmates, 1, regexpr(" ", numOfInmates)-1))

numOfPages <- ceiling(numOfInmates / 10)

for(i in 1:numOfPages){
  
  passFileName <- paste("jail_crawl/output/", "Georgia_brooks_", Sys.Date(), "_", i, ".txt", sep = "")
  rseleniumGetHTML(rsc, passFileName, returnHTML = TRUE, rvestStyle = FALSE)
  if(i != numOfPages){
    
    rsc$findElement(using = "css", "#allInmatesGrid > div.k-pager-wrap.k-grid-pager.pagerTop.k-widget > a:nth-child(4)")$clickElement()
  }
  Sys.sleep(runif(1,4,8))
}

endCrawl(rsc = rsc)