source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_randolph_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://randolphcountyso.org/inmates.html" %>%
  rvestGetHTML(fileName, FALSE)

endCrawl()