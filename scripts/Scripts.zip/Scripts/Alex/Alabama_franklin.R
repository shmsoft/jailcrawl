source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Alabama_franklin_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

#get source code
passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_1", ".txt", sep = "")
myHTML <- rvestGetHTML(link = "https://www.franklinsheriff.org/roster.php?grp=20",
                       fileName = passFileName,
                       returnHTML = TRUE)

#get the number of pages there are
#they display 20 inmates per page

myHTML %>%
  html_nodes("body") %>%
  html_children() -> tbl

tbl[2] %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz

tbl[2] %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() -> tbl
tbl[8] %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() -> tbl

tbl[1] %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_text() -> tbl

numOfPages <- ceiling(as.numeric(substr(tbl[1], regexpr("\\(", tbl)+1, regexpr("\\)", tbl)-1)) / 20)

for(i in 1:numOfPages){
  
  passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_", i, ".txt", sep = "")
  passLink <- paste("https://www.franklinsheriff.org/roster.php?grp=", i*20, sep = "")
  myHTML <- rvestGetHTML(link = passLink,
                 fileName = passFileName,
                 returnHTML = TRUE)
  
  myHTML %>%
    html_nodes("body") %>%
    html_children() -> tbl
  
  tbl[2] %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("https://www.franklinsheriff.org/", finalLinkz, sep = "")

for(j in 1:length(finalLinkz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste(substr(fileName, 1, regexpr(".txt", fileName)-1), "_",
                        substr(finalLinkz[j], regexpr("=", finalLinkz[j]), nchar(finalLinkz[j])),
                        ".txt", sep = "")
  rvestGetHTML(link = passLink, fileName = passFileName, returnHTML = FALSE)
}

endCrawl()