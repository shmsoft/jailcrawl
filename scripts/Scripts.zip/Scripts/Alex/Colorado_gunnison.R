source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_gunnison_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("https://www.gunnisoncounty.org/DocumentCenter/View/4614/Inmate-Daily-Roster", fileName, mode = "wb")

endCrawl()