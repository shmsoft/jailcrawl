source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://12.14.175.12/dcn/inmateGrid.aspx", "Texas_kaufman_")