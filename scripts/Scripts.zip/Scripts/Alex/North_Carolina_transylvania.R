source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://dcn.transylvaniacounty.org/dcn/inmateGrid.aspx", "North_Carolina_transylvania_")