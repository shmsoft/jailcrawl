source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_laurens_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

"http://www.laurenssheriff.org/jailexport/prisonerdata15.php" %>%
  rvestGetHTML(fileName, FALSE)

endCrawl()