source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Arkansas_st_francis_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

passFileName <- paste("jail_crawl/output/", "Arkansas_st_francis_", Sys.Date(), "_", 1, ".txt", sep = "")
"https://www.stfranciscountysheriff.org/roster.php?grp=20" %>%
  rvestGetHTML(passFileName, TRUE) -> myHTML

myHTML %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() -> longList
longList %>%
  html_text() -> numOfInmates
numOfInmates <- numOfInmates[1]
numOfPages <- ceiling(as.numeric(substr(numOfInmates[[1]], regexpr("\\(", numOfInmates[[1]])+1, regexpr("\\)", numOfInmates[[1]])-1))/20)

longList %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz
finalLinkz <- finalLinkz[!is.na(finalLinkz)]

for(i in 2:numOfPages){
  
  passFileName <- paste("jail_crawl/output/", "Arkansas_st_francis_", Sys.Date(), "_", i, ".txt", sep = "")
  passLink <- paste("https://www.stfranciscountysheriff.org/roster.php?grp=", i*20, sep = "")
  myHTML <- rvestGetHTML(passLink, passFileName, TRUE)
  myHTML %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  linkz <- linkz[!is.na(linkz)]
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- paste("https://www.stfranciscountysheriff.org/", finalLinkz, sep = "")
idz <- substr(finalLinkz, regexpr("=", finalLinkz)+1, nchar(finalLinkz))

for(j in 1:length(finalLinkz)){
  
  passLink <- finalLinkz[j]
  passFileName <- paste("jail_crawl/output/", "Arkansas_st_francis_", Sys.Date(), "_", idz[j], ".txt", sep = "")
  rvestGetHTML(passLink, passFileName, FALSE)
}

endCrawl()