library("rvest")
library("magrittr")

rm(list = ls())
closeAllConnections()

source("jail_crawl/crawlSteps.R")
options(stingsAsFactors = FALSE)

fileName <- paste("jail_crawl/output/", "Alabama_cleburne_", Sys.Date(), ".txt", sep = "")
startCrawl(fileName)

#get source code
"http://www.cleburnecountyso.org/cur_inmates.html" %>%
  read_html() %>%
  write_xml(file=fileName)

closeAllConnections()

endCrawl()