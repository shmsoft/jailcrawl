source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Georgia_douglas_", Sys.Date(), ".txt", sep = "")

startCrawl(fileName)

passFileName <- paste("jail_crawl/output/", "Georgia_douglas_", Sys.Date(), "_", 1, ".txt", sep = "")

"https://sheriff.douglas.ga.us/daily-arrests/" %>%
  rvestGetHTML(passFileName, TRUE) -> myHTML

myHTML %>%
  html_nodes("#main-core > ul > li.pag-last > a") %>%
  html_attr("href") -> lastLink
numOfPages <- as.numeric(substr(lastLink, regexpr("page", lastLink)+5, nchar(lastLink)-1))

myHTML %>%
  html_nodes("#container") %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_children() %>%
  html_attr("href") -> finalLinkz

for(i in 2:numOfPages){
  
  passFileName <- paste("jail_crawl/output/", "Georgia_douglas_", Sys.Date(), "_", i, ".txt", sep = "")
  paste("https://sheriff.douglas.ga.us/daily-arrests/page/", i, sep = "") %>%
    rvestGetHTML(passFileName, TRUE) -> myHTML
  
  myHTML %>%
    html_nodes("#container") %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_children() %>%
    html_attr("href") -> linkz
  Sys.sleep(runif(1,10,20))
  finalLinkz <- c(finalLinkz, linkz)
}

finalLinkz <- finalLinkz[substr(finalLinkz, nchar(finalLinkz)-3, nchar(finalLinkz)) == ".pdf"]
finalLinkz <- finalLinkz[!is.na(finalLinkz)]
idz <- substr(finalLinkz, regexpr("arrests_", finalLinkz), nchar(finalLinkz))

for(j in 1:length(idz)){
  
  if(!file.exists(paste("jail_crawl/output/", "Georgia_douglas_", idz[j], sep = ""))){
    
    download.file(url = finalLinkz[j], destfile = paste("jail_crawl/output/", "Georgia_douglas_", idz[j], sep = ""), mode = "wb")
  }
}

endCrawl()