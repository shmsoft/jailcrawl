source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://50.234.4.112/dcn/inmates", fileNameTextOnly = "Tennessee_robertson_")