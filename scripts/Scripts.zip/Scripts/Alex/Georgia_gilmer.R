source("jail_crawl/crawlSteps.R")

offenderIndexGetHTML("Georgia_gilmer_", "http://gilmercoga.offenderindex.com")