source("jail_crawl/crawlSteps.R")

fileName <- paste("jail_crawl/output/", "Colorado_garfield_", Sys.Date(), ".pdf", sep = "")

startCrawl(fileName)

download.file("http://www.garcosheriff.com/PDFs/current_inmates.pdf", fileName, mode = "wb")

endCrawl()