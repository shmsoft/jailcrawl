source("jail_crawl/crawlSteps.R")

dcnGetHTML("http://vpn.houstoncountyso.org:8180/dcn/inmates", fileNameTextOnly = "Alabama_houston_")